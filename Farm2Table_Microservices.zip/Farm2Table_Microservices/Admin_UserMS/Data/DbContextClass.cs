﻿using Admin_UserMS.Models;
using Microsoft.EntityFrameworkCore;

namespace Admin_UserMS.Data
{
  
    public class DbContextClass : DbContext
    {
        protected readonly IConfiguration Configuration;

        public DbContextClass(IConfiguration configuration)
        {
            Configuration = configuration;
        }
        protected override void OnConfiguring(DbContextOptionsBuilder options)
        {
            options.UseSqlServer(Configuration.GetConnectionString("DefaultConnection"));
        }

        public DbSet<Admin_User> Admin_Users { get; set; }
        public DbSet<Login_User> Login_Users { get; set; }

    }
}
