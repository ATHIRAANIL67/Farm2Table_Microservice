﻿using Admin_UserMS.Data;
using Admin_UserMS.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Admin_UserMS.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        public readonly DbContextClass adminDbContextClass;

        public LoginController(DbContextClass _db)
        {
            adminDbContextClass = _db;
        }

        [HttpPost]
        public ActionResult<Login_User> Postadm([FromBody] Login_User adm)
        {

            adminDbContextClass.Login_Users.Add(adm);
            adminDbContextClass.SaveChanges();
            return Ok(adm);
        }
    }
}
