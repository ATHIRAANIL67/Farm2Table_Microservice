﻿using Admin_UserMS.Data;
using Admin_UserMS.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

[Route("api/[controller]")]

[ApiController]

public class AdminUserController : ControllerBase

{

    public readonly DbContextClass adminDbContextClass;

    public AdminUserController(DbContextClass _db)
    {
        adminDbContextClass = _db;
    }

    [HttpGet]
    public async Task<ActionResult> GetAdminUsers()
    {
        return Ok(await adminDbContextClass.Admin_Users.ToListAsync());
    }
    [HttpPost]
    public  ActionResult<Admin_User> Postadm([FromBody] Admin_User adm)
    {

         adminDbContextClass.Admin_Users.Add(adm);
            adminDbContextClass.SaveChanges();
        return Ok(adm);
    }
    [HttpPut("{id:int}")]
    public async Task<ActionResult<Admin_User>> put([FromBody] Admin_User Admin, int id)
    {
        if (id == 0)

        {

            return BadRequest();

        }

        adminDbContextClass.Admin_Users.Update(Admin);

        await adminDbContextClass.SaveChangesAsync();

        return Ok(Admin);

    }

    [HttpDelete("{id:int}")]

    public async Task<ActionResult> Delete(int id)

    {

        var result = adminDbContextClass.Admin_Users.Find(id);

        adminDbContextClass.Admin_Users.Remove(result);

        await adminDbContextClass.SaveChangesAsync();

        return Ok(result);

    }
}



















































































































































































